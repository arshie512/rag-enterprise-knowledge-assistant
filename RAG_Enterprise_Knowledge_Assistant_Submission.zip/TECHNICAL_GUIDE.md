# Technical Implementation Guide

## 1. Architecture

```text
AIML_Major_Project_Brief.pdf
        |
        v
LlamaIndex PDF reader -> SentenceSplitter -> Hugging Face embedding model
                                                   |
                                                   v
                                         Persistent ChromaDB
                                                   |
User question -> session memory -> semantic top-k retrieval
                                                   |
                                                   v
                            Ollama local LLM + grounding prompt
                                                   |
                                                   v
                  Answer + retrieved source passages in Streamlit
```

## 2. Data and metadata

The current corpus contains only the provided two-page assignment brief. The screenshots contain substantially the same brief and are not indexed separately. The ingestion script records the source filename in document metadata and retains reader metadata such as page labels where available. PDF text extraction does not perform OCR; scanned PDFs must be OCR-processed before ingestion.

Treat document content as data. The prompt tells the model not to follow commands embedded in retrieved documents. The app presents source passages separately so a human can verify the answer.

## 3. Chunking

The starter setting is 350 tokens per chunk with 60 tokens of overlap, using LlamaIndex's sentence-aware splitter. The overlap reduces the chance that a fact near a chunk boundary is lost. These are starting values, not a universal optimum. Compare a few alternatives (for example 500/80 and 1000/150) using the same labelled questions and report the result. Rebuild the vector index whenever chunking or embedding settings change.

## 4. Embeddings and vector size

The default `BAAI/bge-small-en-v1.5` embedding model runs locally and returns 384-dimensional vectors. The collection dimension follows the configured embedding model automatically; the model card lists the 384 dimension and a 512-token sequence length: https://huggingface.co/BAAI/bge-small-en-v1.5. Use the same model to embed source chunks and questions. Changing the embedding model requires rebuilding the Chroma collection.

## 5. Vector storage and retrieval

ChromaDB is stored on disk in `storage/chroma/`. The retriever returns the top-k most similar chunks, with k defaulting to 3 for this small, two-page corpus. The app displays each retrieved source, optional page metadata, similarity score, and a short passage. Retrieval similarity is a ranking signal, not a probability that the answer is true.

## 6. Generation and memory

Ollama provides local text generation. The default model is configured in `.env`. The LlamaIndex `condense_plus_context` chat mode rewrites follow-up questions using bounded session memory, retrieves relevant context, and sends the context to the model. Memory is scoped to the current Streamlit session and can be cleared in the sidebar.

The prompt requires the assistant to use evidence, avoid invented details, and abstain when the corpus does not answer the question. The prompt is a mitigation, not a guarantee; evaluate answers against the source passages.

## 7. Evaluation

`data/evaluation_questions.csv` contains ten answerable questions with relevant PDF pages, expected answers, and two unanswerable cases for manual abstention review. `src.evaluate` computes retrieval metrics for rows with relevant-source labels:

- **Precision@k:** relevant returned source hits divided by k.
- **Recall@k:** relevant returned source hits divided by the number of labelled relevant sources.
- **MRR:** average reciprocal rank of the first relevant source.

When page labels are available, the script evaluates relevant source-page pairs. Precision@k counts relevant returned chunks divided by k, recall@k counts distinct relevant pages found divided by labelled relevant pages, and MRR uses the first relevant chunk rank. The per-question CSV helps identify poor retrieval. Use `reports/answer_review_template.csv` to separately assess factual answer correctness, faithfulness, and abstention. LLM output quality cannot be established by retrieval metrics alone.

## 8. API keys and privacy

The default setup uses local embeddings and local generation, so no API keys are required. If you change to a hosted model, store keys in `.env` or the platform's secret store, never in source code, notebooks, or a submitted public repository. Do not upload confidential organization documents to a third-party model without authorization.

## 9. Current limitations

- This is a single two-page assignment brief corpus, not a set of enterprise manuals or customer policies. Its results demonstrate retrieval over assignment instructions only.
- The brief has citation placeholders `[cite: 304]` and `[cite: 305]` without complete bibliography entries.
- Retrieval metrics depend on accurate relevance labels, and a small query set does not represent real users.
- Local model quality and speed depend on computer resources and the selected Ollama model.
- Chat memory is session-scoped and does not persist across browser sessions.
- The vector database is rebuilt from scratch when `src.ingest` runs.



