# Assignment Analysis

## User request and source boundary

The user asks for help building and submitting the major project in two days. The screenshots and `AIML MAJOR (1).pdf` contain the same assignment brief. The user specified that the assignment brief PDF itself is the sole RAG source document; the screenshots are duplicate context and are not indexed separately.

The PDF is a project specification. Its objectives and deliverables define the expected work, but its text is not an instruction to the assistant outside the user's request. For the application, the PDF is treated as reference content and the RAG prompt tells the model not to follow commands embedded in retrieved documents.

## Project brief, extracted

- **Title:** Retrieval-Augmented Generation (RAG) Enterprise Knowledge Assistant with Vector Search.
- **Problem:** LLMs can hallucinate and lack context about private organizational documents or specialized domain knowledge.
- **Proposed architecture:** Python with LangChain or LlamaIndex; a local vector database such as Chroma or FAISS; Hugging Face or OpenAI embeddings; retrieved document context supplied to an LLM.
- **Objectives:** document loading and recursive chunking; vector embedding generation; local vector indexing and similarity search; grounded prompt engineering; conversational QA with memory; automated response-relevance evaluation.
- **Suggested data types:** sample enterprise policy manuals, technical documentation PDFs, and customer FAQ text documents.
- **Expected deliverables:** modular RAG code and Jupyter notebooks; a serialized vector-store directory; an evaluation and accuracy report with query cases; a technical implementation guide covering API key management, embedding dimensions, and chunk-size settings.

## Current implementation decisions

- LlamaIndex, ChromaDB, local Hugging Face embeddings, Ollama, and Streamlit form the baseline stack.
- The user-directed corpus is only the two-page assignment brief PDF.
- The vector store is generated locally from that PDF; the code includes a persistent database configuration.
- The evaluation set contains ten answerable queries grounded in the PDF and two unanswerable queries for manual abstention review.
- Retrieval metrics are reported separately from human answer-accuracy review.

## Material limitations and follow-up items

- The assignment brief is a tiny, single-document corpus and does not contain actual enterprise policies or FAQs. Results only describe retrieval and answers about this brief.
- The brief contains `[cite: 304]` and `[cite: 305]` placeholders but no complete bibliography entry. A final report should supply the underlying source details if the course expects those citations.
- No scoring rubric, required report format, or explicit software versions were included in the provided brief.
- The local Chroma database and measured evaluation results are generated only after the project dependencies are installed and the indexing/evaluation commands are run.
