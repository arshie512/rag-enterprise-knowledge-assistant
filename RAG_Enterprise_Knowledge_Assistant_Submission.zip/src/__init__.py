"""RAG enterprise knowledge assistant."""
