# Project Completion and Submission Checklist

The assignment brief is the only indexed source, as requested. The screenshots contain substantially the same requirements and are not indexed separately. The local RAG app has been launched with Ollama llama3.2:3b, and all 12 manual answer-review questions have been completed.

## Completed deliverables

- [x] Modular Python code for PDF ingestion, chunking, local embeddings, persistent Chroma retrieval, chat, and evaluation.
- [x] Streamlit app launched locally with Ollama; retrieved source passages were inspected.
- [x] Assignment brief PDF indexed as the sole corpus.
- [x] Persistent Chroma database generated and included in the submission ZIP.
- [x] Notebook walkthrough.
- [x] Ten answerable retrieval questions and two unanswerable review questions.
- [x] Retrieval results: Precision@3 = 0.667, Recall@3 = 1.000, MRR = 0.850.
- [x] Manual answer review: 12/12 factually acceptable responses, including both expected abstentions; mean faithfulness 4.92/5.
- [x] Technical implementation guide and evaluation report with limitations.

## Final notes

- The corpus has only two pages. These results demonstrate the requested workflow over the assignment brief; they do not establish performance on a real enterprise knowledge base.
- One answer correctly named recursive chunking but omitted some accompanying detail, so it received a faithfulness score of 4/5.
- The brief contains citation placeholders [cite: 304] and [cite: 305] without full references.
- The Streamlit project disables file watching for compatibility with this environment; restart the app manually after changing code.
- The submission ZIP excludes .venv/, .uv_cache/, storage/models/, storage/tmp/, .env, and unused sample files. Its Chroma index and source PDF are included.
