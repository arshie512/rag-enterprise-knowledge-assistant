# RAG Evaluation and Accuracy Report

## 1. Evaluation setup

- Corpus name and date:
- Number of source files:
- Number of extracted pages/documents:
- Embedding model:
- Vector database and collection:
- Chunk size / overlap:
- Retrieval top-k:
- Generation model:
- Evaluator:

## 2. Retrieval results

Run `python -m src.evaluate --top-k 3`. Copy the actual output below. Do not fill these values with estimates.

| Metric | Result | Interpretation |
|---|---:|---|
| Precision@k | Pending evaluation | Fraction of top-k returned chunks from relevant labelled PDF pages |
| Recall@k | Pending evaluation | Fraction of labelled relevant PDF pages found in the top-k results |
| MRR | Pending evaluation | Average reciprocal rank of the first relevant result |

Include the generated `retrieval_results.csv` with the submission.

## 3. Answer accuracy review

Use `reports/answer_review_template.csv`. Ask each labelled question in the app, record the answer and displayed source files, and have a reviewer compare the answer against the source. Include the two unanswerable cases when calculating abstention behavior. Report:

- Number of answers reviewed:
- Correct answers / accuracy:
- Mean faithfulness score (1-5):
- Unsupported claims observed:
- Abstentions when evidence was missing:
- Limitations and examples:

Retrieval scores measure whether relevant documents were found. They do not establish that the generated answer is factually correct. Report human answer review separately.

## 4. Error analysis

For each failure, record the question, expected source, retrieved source, likely cause (extraction, chunking, embedding/retrieval, prompt, or generation), and a specific improvement. Re-run evaluation after changing one setting at a time.

## 5. Conclusion

Summarize what worked, the known limitations (including scanned PDFs, small corpus size, local model quality, and labelled-query coverage), and what should be improved next.



