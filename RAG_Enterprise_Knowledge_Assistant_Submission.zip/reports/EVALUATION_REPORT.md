# RAG Evaluation and Accuracy Report

## Corpus and method

- Source: data/assignment_brief/AIML_Major_Project_Brief.pdf (2 pages).
- Scope: the assignment brief only; the screenshots contain substantially the same requirements and are not separately indexed.
- Extracted pages: 2.
- Chunking: LlamaIndex SentenceSplitter, 350 tokens per chunk, 60-token overlap.
- Final index: 3 chunks in persistent Chroma collection enterprise_knowledge.
- Embedding: BAAI/bge-small-en-v1.5, 384 dimensions.
- Retrieval: cosine similarity, top-k = 3.
- Retrieval evaluation: 10 answerable questions labelled by relevant PDF page. Two unanswerable questions are reserved for manual abstention review and excluded from retrieval metrics.
- Generation model: Ollama llama3.2:3b, run locally.

## Measured retrieval results

| Metric | Result |
|---|---:|
| Precision@3 | 0.667 |
| Recall@3 | 1.000 |
| MRR | 0.850 |

The per-question values are in retrieval_results.csv. All 10 answerable questions retrieved at least one labelled page in the top three. Some questions returned a chunk from the other page before the relevant page, which is reflected in MRR and precision.

## Chunk-size comparison

A first pass used 800-token chunks with 120-token overlap and produced two chunks (one per page). The saved baseline rankings contained two retrieved chunks per query. Recalculated at the same k = 3, its mean Precision@3 was 0.367, Recall@3 was 1.000, and MRR was 0.850. The final 350/60 configuration produced three chunks and Precision@3 of 0.667, with recall and MRR unchanged. This comparison is specific to the small assignment PDF; a larger corpus needs a broader query set.

## Human answer review and abstention

All 12 cases in answer_review_template.csv were reviewed manually against the brief and the retrieved source panel: 10 answerable questions and 2 questions whose answers are absent.

| Review measure | Result |
|---|---:|
| Factually acceptable answers, including correct abstentions | 12/12 (100%) |
| Mean faithfulness score | 4.92/5 |
| Correct abstentions on unanswerable questions | 2/2 |

One response correctly identified recursive chunking but omitted the brief's mention of text loaders and the purpose of splitting PDFs and Markdown into manageable semantic segments; it received a faithfulness score of 4/5. The other 11 responses received 5/5. This is a small, source-derived manual review, not evidence of accuracy on a broad enterprise corpus.

## Limitations

- The corpus has only two pages and does not include real enterprise policy or technical documents.
- The ten retrieval questions are derived from the same brief, so results do not predict performance on a broader knowledge base.
- The source PDF contains citation placeholders [cite: 304] and [cite: 305] but no full bibliography entries.
- Scanned PDFs would need OCR; this PDF is text-based.
- The results are reproducible only with the declared corpus, model, chunking, and top-k settings.
